# AI HDR Camera — Android wrapper

This is the native Android host required for real Camera2 capture. The deployed web app is loaded inside a WebView; `AIHDRNative` exposes native capture to the page.

## Build

- Android Studio with Android Gradle Plugin 8.7.3
- JDK 17
- Android SDK 35
- A physical Android device with Camera2 support

Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

## Architecture

- WebView hosts the deployed camera interface.
- `AIHDRNative.capture()` receives mode, EV offset, lens direction and callback ID.
- Camera2 obtains a metered baseline, then captures three sequential JPEG exposures.
- Manual sensor exposure is used when the camera advertises MANUAL_SENSOR; otherwise AE compensation is used within the device's supported range.
- OpenCV aligns the bracket with AlignMTB and fuses it with MergeMertens, then applies LAB CLAHE, saturation enhancement and sharpening.
- The native bridge returns the final JPEG to the web UI.

## Important device caveats

Camera2 support varies by device. Exact manual exposure bracketing is not available on every LEGACY-level camera. On those devices the implementation uses AE compensation where supported; if the device cannot bracket exposures, capture should be treated as a compatibility limitation, not full HDR. The app must be tested on the target phone and its camera HAL.

The web UI stops its browser preview stream before native capture to avoid competing camera sessions, then resumes the preview. The APK needs the camera permission. The web host must remain reachable over HTTPS. OpenCV initialization is checked before an HDR capture is accepted; Standard Camera2 capture remains available if OpenCV fails to initialize.

This source bundle is an Android Studio project, not a prebuilt APK. Build and test it in Android Studio on a physical device before distributing it.
