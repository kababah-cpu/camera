package com.fieldlight.aihdr

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.opencv.android.OpenCVLoader
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var camera: Camera2HdrCapture
    private var openCvReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        camera = Camera2HdrCapture(this)
        openCvReady = OpenCVLoader.initLocal()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 41)
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                            == PackageManager.PERMISSION_GRANTED) {
                            request.grant(request.resources)
                        } else {
                            request.deny()
                        }
                    }
                }
            }
            addJavascriptInterface(NativeCameraBridge(), "AIHDRNative")
            loadUrl("https://ai-hdr-camera-nw6va0.v2.appdeploy.ai/")
        }
        setContentView(web)
    }

    inner class NativeCameraBridge {
        @JavascriptInterface fun isAvailable(): Boolean = true

        @JavascriptInterface
        fun capture(mode: String, ev: Double, facing: String, requestId: String) {
            worker.execute {
                try {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                        throw SecurityException("Camera permission is required.")
                    }
                    if (mode == "hdr" && !openCvReady) {
                        throw IllegalStateException("OpenCV could not be initialized on this device.")
                    }
                    val jpeg = if (mode == "hdr") camera.captureHdr(ev, facing == "user")
                               else camera.captureStandard(facing == "user")
                    val encoded = android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP)
                    deliver(requestId, encoded, if (mode == "hdr") "Camera2 + OpenCV HDR" else "Camera2 Standard", null)
                } catch (t: Throwable) {
                    deliver(requestId, "", "", t.message ?: "Native camera capture failed.")
                }
            }
        }
    }

    private fun deliver(id: String, base64: String, mode: String, error: String?) {
        val qId = org.json.JSONObject.quote(id)
        val qData = org.json.JSONObject.quote(base64)
        val qMode = org.json.JSONObject.quote(mode)
        val qError = org.json.JSONObject.quote(error ?: "")
        runOnUiThread {
            web.evaluateJavascript(
                "window.onNativeCaptureResult && window.onNativeCaptureResult($qId,$qData,$qMode,$qError);",
                null
            )
        }
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("AIHDRNative")
        web.destroy()
        worker.shutdown()
        camera.close()
        super.onDestroy()
    }
}
