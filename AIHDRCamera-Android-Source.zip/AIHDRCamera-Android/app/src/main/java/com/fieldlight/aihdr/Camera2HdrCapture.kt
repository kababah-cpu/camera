package com.fieldlight.aihdr

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Range
import android.util.Size
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgcodecs.Imgcodecs
import org.opencv.imgproc.CLAHE
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import java.io.ByteArrayOutputStream
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class Camera2HdrCapture(private val context: Context) {
    private val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val thread = HandlerThread("Camera2HdrCapture").apply { start() }
    private val handler = Handler(thread.looper)
    @Volatile private var activeDevice: CameraDevice? = null
    @Volatile private var activeReader: ImageReader? = null

    fun captureStandard(front: Boolean): ByteArray = withCamera(front) { device, session, reader, queue, chars ->
        val request = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
            addTarget(reader.surface)
            set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            set(CaptureRequest.JPEG_QUALITY, 96.toByte())
        }.build()
        session.capture(request, null, handler)
        queue.poll(5, TimeUnit.SECONDS) ?: error("Camera did not return a JPEG.")
    }

    fun captureHdr(ev: Double, front: Boolean): ByteArray = withCamera(front) { device, session, reader, queue, chars ->
        val metering = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
            addTarget(reader.surface)
            set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
            val afModes = chars.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES).orEmpty()
            set(
                CaptureRequest.CONTROL_AF_MODE,
                if (afModes.contains(CaptureRequest.CONTROL_AF_MODE_AUTO))
                    CaptureRequest.CONTROL_AF_MODE_AUTO
                else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
            set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
            set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            set(CaptureRequest.JPEG_QUALITY, 96.toByte())
        }.build()

        var baseExposure = 10_000_000L
        var baseIso = 200
        val metered = CountDownLatch(1)
        session.capture(metering, object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                baseExposure = result.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: baseExposure
                baseIso = result.get(CaptureResult.SENSOR_SENSITIVITY) ?: baseIso
                // The AF trigger request lets AUTO AF lock where supported. Keep the
                // same AF mode for the bracket and lock AWB on subsequent requests.
                metered.countDown()
            }
        }, handler)
        metered.await(2, TimeUnit.SECONDS)
        queue.poll(4, TimeUnit.SECONDS) // discard metering JPEG; use the result only

        val manual = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            ?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) == true
        val exposureRange = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val isoRange = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val compensationRange = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        val step = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)
        val images = ArrayList<ByteArray>(3)

        // Sequential capture plus one image-queue read per request keeps JPEGs paired with requests.
        for (offset in listOf(-2.0, 0.0, 2.0)) {
            val adjusted = (offset + ev).coerceIn(-3.0, 3.0)
            val builder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(reader.surface)
                val afModes = chars.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES).orEmpty()
                set(
                    CaptureRequest.CONTROL_AF_MODE,
                    if (afModes.contains(CaptureRequest.CONTROL_AF_MODE_AUTO))
                        CaptureRequest.CONTROL_AF_MODE_AUTO
                    else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                )
                set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE)
                set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
                if (chars.get(CameraCharacteristics.CONTROL_AWB_LOCK_AVAILABLE) == true) {
                    set(CaptureRequest.CONTROL_AWB_LOCK, true)
                }
                set(CaptureRequest.JPEG_QUALITY, 96.toByte())
                if (manual && exposureRange != null && isoRange != null) {
                    set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                    val target = (baseExposure * 2.0.pow(adjusted)).toLong()
                    set(CaptureRequest.SENSOR_EXPOSURE_TIME, target.coerceIn(exposureRange.lower, exposureRange.upper))
                    set(CaptureRequest.SENSOR_SENSITIVITY, baseIso.coerceIn(isoRange.lower, isoRange.upper))
                } else {
                    set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                    val compensation = if (step != null && step.toFloat() > 0f) (adjusted / step.toFloat()).toInt() else 0
                    val clamped = compensationRange?.let { compensation.coerceIn(it.lower, it.upper) } ?: 0
                    set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, clamped)
                }
            }.build()
            session.capture(builder, null, handler)
            images += (queue.poll(5, TimeUnit.SECONDS) ?: error("A bracket exposure timed out."))
        }
        OpenCvFusion.merge(images)
    }

    private fun <T> withCamera(front: Boolean, block: (CameraDevice, CameraCaptureSession, ImageReader, ArrayBlockingQueue<ByteArray>, CameraCharacteristics) -> T): T {
        val cameraId = manager.cameraIdList.firstOrNull { id ->
            val facing = manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)
            facing == if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
        } ?: manager.cameraIdList.firstOrNull() ?: error("No camera is available.")
        val chars = manager.getCameraCharacteristics(cameraId)
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?: error("Camera stream configuration is unavailable.")
        val size = map.getOutputSizes(ImageFormat.JPEG).orEmpty()
            .filter { it.width.toLong() * it.height <= 12_000_000L }
            .maxByOrNull { it.width.toLong() * it.height } ?: Size(1920, 1080)
        val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 4)
        val queue = ArrayBlockingQueue<ByteArray>(4)
        reader.setOnImageAvailableListener({ source ->
            source.acquireNextImage()?.use { image ->
                val buffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                queue.offer(bytes)
            }
        }, handler)
        activeReader = reader

        val opened = CountDownLatch(1)
        var openError: Throwable? = null
        manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(camera: CameraDevice) { activeDevice = camera; opened.countDown() }
            override fun onDisconnected(camera: CameraDevice) { camera.close(); openError = IllegalStateException("Camera disconnected."); opened.countDown() }
            override fun onError(camera: CameraDevice, error: Int) { camera.close(); openError = IllegalStateException("Camera2 error: $error"); opened.countDown() }
        }, handler)
        check(opened.await(5, TimeUnit.SECONDS)) { "Timed out opening the camera." }
        openError?.let { throw it }
        val device = activeDevice ?: error("Camera failed to open.")
        val configured = CountDownLatch(1)
        var session: CameraCaptureSession? = null
        var configError: Throwable? = null
        device.createCaptureSession(listOf(reader.surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(value: CameraCaptureSession) { session = value; configured.countDown() }
            override fun onConfigureFailed(value: CameraCaptureSession) { configError = IllegalStateException("Camera session configuration failed."); configured.countDown() }
        }, handler)
        check(configured.await(5, TimeUnit.SECONDS)) { "Timed out configuring the camera." }
        configError?.let { throw it }
        val captureSession = session ?: error("Camera session unavailable.")
        try {
            block(device, captureSession, reader, queue, chars)
        } finally {
            try { captureSession.stopRepeating() } catch (_: Throwable) {}
            captureSession.close()
            device.close()
            reader.close()
            activeDevice = null
            activeReader = null
        }
    }

    fun close() {
        try { activeDevice?.close() } catch (_: Throwable) {}
        try { activeReader?.close() } catch (_: Throwable) {}
        thread.quitSafely()
    }
}

private object OpenCvFusion {
    fun merge(jpegs: List<ByteArray>): ByteArray {
        require(jpegs.size == 3) { "HDR requires three captured exposures." }
        val source = jpegs.map { Imgcodecs.imdecode(MatOfByte(*it), Imgcodecs.IMREAD_COLOR) }
        val aligned = ArrayList<Mat>()
        val output = Mat()
        val mats = ArrayList<Mat>()
        try {
            require(source.all { !it.empty() }) { "One exposure could not be decoded." }
            val align = Photo.createAlignMTB()
            align.process(source, aligned)
            val fusion = Photo.createMergeMertens()
            fusion.process(aligned, output)

            val normalized = Mat()
            output.convertTo(normalized, CvType.CV_8UC3, 255.0)
            val lab = Mat()
            Imgproc.cvtColor(normalized, lab, Imgproc.COLOR_BGR2Lab)
            val channels = ArrayList<Mat>()
            Core.split(lab, channels)
            val clahe = Imgproc.createCLAHE(2.0, Size(8.0, 8.0))
            val enhancedL = Mat()
            clahe.apply(channels[0], enhancedL)
            enhancedL.copyTo(channels[0])
            Core.merge(channels, lab)
            val contrast = Mat()
            Imgproc.cvtColor(lab, contrast, Imgproc.COLOR_Lab2BGR)

            val hsv = Mat()
            Imgproc.cvtColor(contrast, hsv, Imgproc.COLOR_BGR2HSV)
            val hsvChannels = ArrayList<Mat>()
            Core.split(hsv, hsvChannels)
            Core.multiply(hsvChannels[1], Scalar(1.12), hsvChannels[1])
            Core.min(hsvChannels[1], Scalar(255.0), hsvChannels[1])
            Core.merge(hsvChannels, hsv)
            val vibrant = Mat()
            Imgproc.cvtColor(hsv, vibrant, Imgproc.COLOR_HSV2BGR)

            val blurred = Mat()
            Imgproc.GaussianBlur(vibrant, blurred, Size(0.0, 0.0), 1.2)
            val sharpened = Mat()
            Core.addWeighted(vibrant, 1.35, blurred, -0.35, 0.0, sharpened)
            val encoded = MatOfByte()
            check(Imgcodecs.imencode(".jpg", sharpened, encoded)) { "Could not encode fused JPEG." }
            return encoded.toArray()
        } finally {
            source.forEach { it.release() }
            aligned.forEach { it.release() }
            output.release()
        }
    }
}
